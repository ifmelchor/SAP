      integer*4 maxndat
      parameter(maxnsta=30,maxlwin=1024,maxndat=360000)  
      parameter(distan=.5,maxarray=4,maxgrid=401,rad=57.29578)
      parameter(maxnp=4)

